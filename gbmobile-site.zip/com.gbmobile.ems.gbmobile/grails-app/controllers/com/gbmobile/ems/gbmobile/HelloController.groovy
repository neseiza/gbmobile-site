package com.gbmobile.ems.gbmobile

class HelloController {

    def index() { 
		render "Hello World!"    
    }
}
